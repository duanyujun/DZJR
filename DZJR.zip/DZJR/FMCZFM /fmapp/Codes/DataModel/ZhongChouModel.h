//
//  ZhongChouModel.h
//  fmapp
//
//  Created by apple on 15/5/8.
//  Copyright (c) 2015年 yk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZhongChouModel : NSObject

@end
