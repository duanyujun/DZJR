//
//  SetUpPasswordController.h
//  fmapp
//
//  Created by 张利广 on 14-5-19.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#import "FMViewController.h"
/** 修改密码设置界面
 
 *@See  在本界面中用户需要输入原密码、新密码、确认密码等信息，然后提交到服务器验证
 **/
@interface SetUpPasswordController : FMViewController<UITextFieldDelegate>

@end
