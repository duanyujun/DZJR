//
//  FMStrings.h
//  fmapp
//
//  Created by 李 喻辉 on 14-5-9.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#ifndef fmapp_FMStrings_h
#define fmapp_FMStrings_h

#define LOADMORE_LOADING            @"正在加载..."
#define LOADMORE_LOADOVER           @"加载完毕"
#define LOADMORE_LOADFAILD          @"加载失败"

#endif
