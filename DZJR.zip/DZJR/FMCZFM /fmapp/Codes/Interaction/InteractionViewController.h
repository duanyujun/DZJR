//
//  InteractionViewController.h
//  fmapp
//
//  Created by 李 喻辉 on 14-5-8.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface InteractionViewController : FMViewController

typedef NS_ENUM(NSInteger, ProjectResquestType)
{
    ProjectResquestTypeAll                    = 0,         
    ProjectResquestTypeDanbao                 = 1,
    ProjectResquestTypeDiya                   = 2,
    ProjectResquestTypeZHaiquan               = 3
    
};


@end
