//
//  ProjectCell.h
//  fmapp
//
//  Created by apple on 15/3/12.
//  Copyright (c) 2015年 yk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProjectModel.h"

@interface ProjectCell : UITableViewCell

- (void) displayQuestion:(ProjectModel* )model;


@end
