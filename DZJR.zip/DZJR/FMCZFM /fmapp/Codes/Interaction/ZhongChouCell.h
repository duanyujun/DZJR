//
//  ZhongChouCell.h
//  fmapp
//
//  Created by apple on 15/5/13.
//  Copyright (c) 2015年 yk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProjectModel.h"

@interface ZhongChouCell : UITableViewCell

- (void) displayQuestion:(ProjectModel* )model;

@end
