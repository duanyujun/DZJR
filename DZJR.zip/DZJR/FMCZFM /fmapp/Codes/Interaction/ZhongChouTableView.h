//
//  ZhongChouTableView.h
//  fmapp
//
//  Created by apple on 15/5/8.
//  Copyright (c) 2015年 yk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZhongChouTableView : UIView

- (id)initWithFrame:(CGRect)frame withDataStyle:(NSInteger )m_dataStyle withModuleStyle:(NSInteger)m_moduleStyle;

@end
