//
//  AboutController.h
//  fmapp
//
//  Created by 张利广 on 14-5-14.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#import "FMViewController.h"

@interface AboutController : FMViewController

@end
