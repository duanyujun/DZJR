//
//  FindPassWordViewController.h
//  fmapp
//
//  Created by apple on 15/4/8.
//  Copyright (c) 2015年 yk. All rights reserved.
//

#import "FMViewController.h"

@interface FindPassWordViewController : FMViewController

@property (nonatomic,copy) NSString   *telStr;

@end
