//
//  RegisterController.h
//  fmapp
//
//  Created by 张利广 on 14-5-14.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#import "FMViewController.h"

/** 注册新用户界面设置
 
 *
 *@See 用户可以此为如果，进行登录操作设置
 */
@interface RegisterController : FMViewController

- (id)initWithTel:(NSString *)tel;
@end
