//
//  RoadMainViewController.h
//  fmapp
//
//  Created by 张利广 on 14-10-10.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#import "FMViewController.h"
#import "ZBarSDK.h"

@interface RoadMainViewController : FMViewController<ZBarReaderDelegate>

@end
