//
//  FMSolidSkin.h
//  fmapp
//
//  Created by 李 喻辉 on 14-8-14.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDefaultSkin.h"

@interface FMSolidSkin : FMDefaultSkin

- (id)initWithColor:(UIColor *)tintColor;

@end
