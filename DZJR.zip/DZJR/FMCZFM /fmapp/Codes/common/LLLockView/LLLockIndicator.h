//
//  LLLockIndicator.h
//  LockSample
//
//  Created by Lugede on 14/11/13.
//  Copyright (c) 2014年 lugede.cn. All rights reserved.
//
//  缩小的指示器

#import <UIKit/UIKit.h>
#import "LLLockConfig.h"

@interface LLLockIndicator : UIView

- (void)setPasswordString:(NSString*)string;

@end
