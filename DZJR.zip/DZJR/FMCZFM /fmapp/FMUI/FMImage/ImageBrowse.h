//
//  ImageBrowse.h
//  fmapp
//
//  Created by 李 喻辉 on 14-6-9.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMImageView.h"


@interface ImageBrowse : UIViewController 

//显示相册
//images            FMImage
//rect              原图在window中的位置
//currentIndex      初始显示相片索引
- (void)showPhotos:(NSArray* )images srcRect:(CGRect)rect currentIndex:(NSInteger)currentIndex;
@end
