//
//  LoadProgressView.h
//  ArtAuthority
//
//  Created by Ma Yiming on 13-7-16.
//  Copyright (c) 2013年 Ma Yiming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadProgressView : UIView

@property (nonatomic,assign) CGFloat progressPercentValue;//进度%值

@end
