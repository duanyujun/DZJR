//
//  PlaceHolderTextView.h
//  fmapp
//
//  Created by 李 喻辉 on 14-5-8.
//  Copyright (c) 2014年 yk. All rights reserved.
//


/**
 * @brief 带占位符的TextView
 */
@interface PlaceHolderTextView : UITextView

@property (nonatomic, retain) NSString *placeHolder;
@property (nonatomic, retain) UIColor *placeHolderColor;
@property (nonatomic, retain) UILabel *placeHolderLabel;
@property (nonatomic, retain) UIImage *placeHodlerBackgroundImage;

- (void)textChanged:(NSNotification *)notification;

@end
