//
//  HUIKeybord.h
//  fmapp
//
//  Created by 李 喻辉 on 14/11/7.
//  Copyright (c) 2014年 yk. All rights reserved.
//

#ifndef fmapp_HUIKeybord_h
#define fmapp_HUIKeybord_h

typedef enum {
    HUIKeybordNone,
    HUIKeybordDefault,
    HUIKeybordExpress
} HUIKeybordType;

#pragma mark -获取键盘视图
extern UIView* GetKeyBoardView();

#endif
