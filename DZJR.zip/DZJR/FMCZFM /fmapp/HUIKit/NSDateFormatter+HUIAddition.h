//
//  NSDateFormatter+HUIAddition.h
//  HUIKit
//
//  Created by lyh on 14-5-7.
//  Copyright (c) 2014年 com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateFormatter (HUIAddition)

//Return a short date and time style formatter with current local 
//like @"13-1-4 上午11:19"
+ (NSDateFormatter *)localShortStyleFormatter;

@end
