//
//  UIDevice+HUIAddtion.m
//  HUIKit
//
//  Created by lyh on 14-5-7.
//  Copyright (c) 2014年 com. All rights reserved.
//
//

#import "UIDevice+HUIAddtion.h"

@implementation UIDevice (HUIAddtion)

@end
